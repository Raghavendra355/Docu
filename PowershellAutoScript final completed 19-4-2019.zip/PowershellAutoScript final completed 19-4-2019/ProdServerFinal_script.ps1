﻿$servers = get-content -Path "D:\PowershellAutoScript\serversSpool.txt"
$logfile = "D:\PowershellAutoScript\serverLogs.log"
$Date =  Get-date -Format dd-MMM-yyyy-hh:mm
"***************************Logging Started on $Date ***********************************" | Out-File -FilePath $logfile -Append
foreach ($server in $servers)
{ 
    $a = (Get-Service -ComputerName $server -Name Spooler | where-object {$_.Status -eq "Running"} | Format-Table -Property Name, DependentServices)
    if (!$a) 
        {"$Date :: The spooler is already Stopped on "+ $server | Out-File -FilePath $logfile -Append} 

    else 
        {"$Date :: The spooler is running on "+ $server | Out-File -FilePath $logfile -Append} 
    $a | Out-File -FilePath $logfile -Append
    "$date :: Stopping Services & Clearing Print Jobs  on $Server" | Out-File -FilePath $logfile -Append
    Get-WmiObject -Class Win32_Service -Filter 'name="spooler"' -ComputerName $Server | Invoke-WmiMethod -Name StopService | out-null 
    "$Date :: Spooler service Stopped on $Server" | Out-File -FilePath $logfile -Append
    Get-ChildItem "\\$server\D`$\SPOOL\*.*" | Remove-Item -Recurse
    "$Date :: Removed pending print jobs from D:\Spool on $Server" | Out-File -FilePath $logfile -Append
    Get-WmiObject -Class Win32_Service -Filter 'name="spooler"' -ComputerName $Server | Invoke-WmiMethod -Name StartService | out-null
    "$Date :: Spooler service has been started on "+ $server | Out-File -FilePath $logfile -Append

}

function MAIL
{
    $1=Get-Date
    $From = 'printlog@marriott.com'
    $To = 'raghavendra.ramappa@marriott-sp.com'
    $Attachment = 'D:\PowershellAutoScript\serverLogs.log'
    $Subject = "Automated Mail:: Status on Pending Print Job Clearance in Print Servers"
    $Body = "
Hi Team,

This is an Automated mail for script scheduled for Pending print job clearance on the print servers.
Find the attached log file which gives the details of each operation performed on each print server for your kind reference. 
If any further clarification, please contact  wpsteam@marriott.com 


NOTE :: This attached log file will be the final copy of the log file, and this will not be available in any other location after you received this mail.
"
    $SMTPServer = "smtp.marriott.com"
    try{
        Send-MailMessage -From $From -to $To -Subject $Subject -Body $Body -SmtpServer $SMTPServer -Attachments $Attachment
        
       }
    catch{
        
        logs("*CRITICAL*     : Unable to send email") #log19-E
          }
} 

MAIL

Start-Sleep -Seconds 10
Remove-Item -Path "D:\PowershellAutoScript\serverLogs.log" -Force